namespace Org.Ktu.Isk.P175B602.Autonuoma.Models;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;


/// <summary>
/// Model of 'Savininkas' entity.
/// </summary>
public class Savininkas
{
	[DisplayName("Vardas")]
	[Required]
	public string Vardas { get; set; }

	[DisplayName("Pavardė")]
	[Required]
	public string Pavarde { get; set; }

    [DisplayName("Savininko asmens kodas")]
	[Required]
	public int Savininko_asmens_kodas { get; set; }

	[DisplayName("Amzius")]
	[Required]
	public int Amzius { get; set; }

	[DisplayName("Banko saskaita")]
	[Required]
	public string Banko_saskaita { get; set; }

    [DisplayName("Adresas")]
	[Required]
	public string Adresas { get; set; }

	[DisplayName("Lytis")]
	[Required]
	public int Lytis { get; set; }

}
