namespace Org.Ktu.Isk.P175B602.Autonuoma.Models;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;


/// <summary>
/// Model of 'Gamykla' entity.
/// </summary>
public class Gamykla
{
	[DisplayName("Salis")]
	[Required]
	public string Salis { get; set; }
	
	[DisplayName("Miestas")]
	[Required]
	public string Miestas { get; set; }

	[DisplayName("Adresas")]
	[Required]
	public string Adresas { get; set; }

	[DisplayName("Darbo laikas")]
	[DataType(DataType.Date)]
	[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
	[Required]
	public DateTime? Darbo_laikas { get; set; }

	[DisplayName("Irangos kiekis")]
	[Required]
	public string Irangos_kiekis { get; set; }

	[DisplayName("ID")]
	[Required]
	public int id_GAMYKLA { get; set; }
}
