namespace Org.Ktu.Isk.P175B602.Autonuoma.Models;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;


/// <summary>
/// Model of 'Iranga' entity.
/// </summary>
public class Iranga
{
	[DisplayName("Tipas")]
	[Required]
	public string Tipas { get; set; }

    [DisplayName("Pagaminimo data")]
	[DataType(DataType.Date)]
	[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
	public DateTime? Pagaminimo_data { get; set; }
	
	[DisplayName("Gamintojas")]
	public string Gamintojas { get; set; }

	[DisplayName("Garantijos laikotarpis")]
	[Required]
	public int Garantijos_laikotarpis { get; set; }

	

	[DisplayName("Medziagos is kuriu pagaminta")]
	[Required]
	public string Medziagos_is_kuriu_pagaminta { get; set; }

	[DisplayName("ID")]
	[Required]
	public int id_IRANGA { get; set; }
}
