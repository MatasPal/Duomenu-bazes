namespace Org.Ktu.Isk.P175B602.Autonuoma.Models.ServicesReport1;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;


/// <summary>
/// View model for a single service in services report.
/// </summary>
public class Paslauga
{
	[DisplayName("Id")]
	public int Id { get; set; }

	[DisplayName("Sporto salės adresas")]
	public string Pavadinimas { get; set; }
	
	[DisplayName("Įrengimo data")]
	public DateTime Irengimo_Data { get; set; }

	[DisplayName("Savininkas")]
	public string Savininko_Vardas_Pavarde{get;set;}

	[DisplayName("Darbuotojų kiekis")]
	public int DKiekis { get; set; }

	[DisplayName("Vietų kiekis")]
	public int VKiekis { get; set; }
}

/// <summary>
/// View model of the whole report.
/// </summary>
public class Report
{
	[DataType(DataType.DateTime)]
	[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
	public DateTime? DateFrom { get; set; }

	[DataType(DataType.DateTime)]
	[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
	public DateTime? DateTo { get; set; }

	public List<Paslauga> Paslaugos { get; set; }

	public int VisoDarbuotoju { get; set; }

	public int VisoVietu { get; set; }
}
