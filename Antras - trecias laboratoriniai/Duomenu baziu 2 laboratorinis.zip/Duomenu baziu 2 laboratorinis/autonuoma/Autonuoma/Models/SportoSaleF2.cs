namespace Org.Ktu.Isk.P175B602.Autonuoma.Models.SportoSaleF2;

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;


/// <summary>
/// 'SportoSale' in list form.
/// </summary>
public class SportoSaleL
{
	[DisplayName("Salis")]
	public string Salis { get; set; }

    [DisplayName("Miestas")]
	public string Miestas { get; set; }

    [DisplayName("Adresas")]
	public string Adresas { get; set; }


	[DisplayName("Darbo laikas")]
	public string Darbo_laikas { get; set; }


	[DisplayName("Vietu kiekis")]
	public int Vietu_kiekis { get; set; }


	[DisplayName("Darbuotoju kiekis")]
	public int Darbuotoju_kiekis { get; set; }

	[DisplayName("Irengimo data")]
	[DataType(DataType.Date)]
	[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
	public DateTime? Irengimo_data { get; set; }

    [DisplayName("ID")]
	public int id_SPORTO_SALE { get; set; }
}


/// <summary>
/// 'SportoSale' in create and edit forms.
/// </summary>
public class SportoSaleCE
{
	/// <summary>
	/// Entity data.
	/// </summary>
	public class SportoSaleM
	{
		public List<SportoSaleCE> SportoSales { get; set; }


	    [DisplayName("Salis")]
        [Required]
	    public string Salis { get; set; }

        [DisplayName("Miestas")]
        [Required]
	    public string Miestas { get; set; }

        [DisplayName("Adresas")]
	    public string Adresas { get; set; }


	    [DisplayName("Darbo laikas")]
        [Required]
		[DataType(DataType.DateTime)]
	    public string Darbo_laikas { get; set; }


	    [DisplayName("Vietu kiekis")]
    	public int Vietu_kiekis { get; set; }


	    [DisplayName("Irengimo data")]
	    [DataType(DataType.Date)]
	    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
	    public DateTime? Irengimo_data { get; set; }


	    [DisplayName("Darbuotoju kiekis")]
	    public int Darbuotoju_kiekis { get; set; }

        [DisplayName("Ar dirba visa para")]
	    public int Ar_dirba_visa_para { get; set; }

        [DisplayName("ID")]
        [Required]
	    public int id_SPORTO_SALE { get; set; }

        [DisplayName("Sporto sales savininkas")]
	    public int fk_SAVININKAS_Savininko_asmens_kodas { get; set; }

		//[DisplayName("Uzsakymas")]
		//[Required]
		//public string FkUzsakymas { get; set; }

	}

	/// <summary>
	/// Representation of 'Uzsakymas' entity in 'Sutartis' edit form.
	/// </summary>
	public class UzsakymasM
	{
		
		//public IList<SelectListItem> Uzsak { get; set; }

		/// <summary>
		/// ID of the record in the form. Is used when adding and removing records.
		/// </summary>
		public int InListId { get; set; }

		[DisplayName("Uzsakymas")]
		[Required]
		public string Uzsakymas { get; set; }

		[DisplayName("Kiekis")]
		[Required]
		[Range(1, int.MaxValue)]
		public int Kiekis { get; set; }

		[DisplayName("Data")]
		[Required]
		public DateTime Data { get; set; }
	}

	/// <summary>
	/// Select lists for making drop downs for choosing values of entity fields.
	/// </summary>
	public class ListsM
	{
		[ValidateNever]
		public IList<SelectListItem> Savininkai { get; set; }
		[ValidateNever]
		public IList<SelectListItem> Gamyklos { get; set; }
		[ValidateNever]
		public IList<SelectListItem> Irangos { get; set; }
		[ValidateNever]
		public IList<SelectListItem> Uzsakymai { get; set; }

	}


	/// <summary>
	/// Sutartis.
	/// </summary>
	public SportoSaleM SportoSale { get; set; } = new SportoSaleM();

	/// <summary>
	/// Sutartis.
	/// </summary>
	public Iranga Irangos { get; set; } = new Iranga();

	/// <summary>
	/// Related 'UzsakytaPaslauga' records.
	/// </summary>
	[ValidateNever]
	public IList<UzsakymasM> UzsakytosPaslaugos { get; set;  } = new List<UzsakymasM>();

	/// <summary>
	/// Lists for drop down controls.
	/// </summary>
	public ListsM Lists { get; set; } = new ListsM();
}


