namespace Org.Ktu.Isk.P175B602.Autonuoma.Repositories;

using MySql.Data.MySqlClient;

using Newtonsoft.Json;

using Org.Ktu.Isk.P175B602.Autonuoma.Models.SportoSaleF2;


/// <summary>
/// Database operations related to 'Sporto sale' entity.
/// </summary>
public class SportoSaleF2Repo
{
	public static List<SportoSaleL> ListSportoSale()
	{
		var query =
			$@"SELECT
				s.salis,
				s.miestas,
				s.adresas,
				s.darbo_laikas,
				s.vietu_kiekis,
				s.irengimo_data,
				s.darbuotoju_kiekis,
				s.id_sporto_sale
			FROM
				`sporto_sales` s 
			ORDER BY s.id_sporto_sale DESC";

		var drc = Sql.Query(query);

		var result =
			Sql.MapAll<SportoSaleL>(drc, (dre, t) => {
				t.Salis = dre.From<string>("salis");
				t.Miestas = dre.From<string>("miestas");
				t.Adresas = dre.From<string>("adresas");
				t.Darbo_laikas = dre.From<string>("darbo_laikas");
				t.Vietu_kiekis = dre.From<int>("vietu_kiekis");				t.Darbuotoju_kiekis = dre.From<int>("darbuotoju_kiekis");
				t.id_SPORTO_SALE = dre.From<int>("id_SPORTO_SALE");			
			});

		return result;
	}

	public static SportoSaleCE FindSportoSaleCE(int id)
	{
		var query = $@"SELECT * FROM `sporto_sales` WHERE id_SPORTO_SALE=?id";
		var drc =
			Sql.Query(query, args => {
				args.Add("?id", id);
			});

		var result =
			Sql.MapOne<SportoSaleCE>(drc, (dre, t) => {
				//make a shortcut
				var sut = t.SportoSale;

				//
				sut.Salis = dre.From<string>("salis");
				sut.Miestas = dre.From<string>("miestas");
				sut.Adresas = dre.From<string>("adresas");
				sut.Darbo_laikas = dre.From<string>("darbo_laikas");
				sut.Vietu_kiekis = dre.From<int>("vietu_kiekis");
				sut.Irengimo_data = dre.From<DateTime>("irengimo_data");
				sut.Darbuotoju_kiekis = dre.From<int>("darbuotoju_kiekis");
				sut.Ar_dirba_visa_para = dre.From<int>("ar_dirba_visa_para");
				sut.id_SPORTO_SALE = dre.From<int>("id_SPORTO_SALE");
				sut.fk_SAVININKAS_Savininko_asmens_kodas = dre.From<int>("fk_SAVININKASSavininko_asmens_kodas");
			});

		return result;
	}

	public static int InsertSportoSale(SportoSaleCE sutCE)
	{
		var query =
			$@"INSERT INTO `sporto_sales`
			(
				`salis`,
				`miestas`,
				`adresas`,
				`darbo_laikas`,
				`vietu_kiekis`,
				`irengimo_data`,
				`darbuotoju_kiekis`,
				`ar_dirba_visa_para`,
				`fk_SAVININKASSavininko_asmens_kodas`
			)
			VALUES(
				?salis,
				?miestas,
				?adresas,
				?darblaik,
				?vietkiek,
				?irengdat,
				?darbkiek,
				?ardirbvispar,
				?savinink
			)";

		var nr =
			Sql.Insert(query, args => {
				//make a shortcut
				var sut = sutCE.SportoSale;

				//
				args.Add("?salis", sut.Salis);
				args.Add("?miestas", sut.Miestas);
				args.Add("?adresas", sut.Adresas);
				args.Add("?darblaik", sut.Darbo_laikas);
				args.Add("?vietkiek", sut.Vietu_kiekis);
				args.Add("?irengdat", sut.Irengimo_data);
				args.Add("?darbkiek", sut.Darbuotoju_kiekis);
				args.Add("?ardirbvispar", 1);
				args.Add("?id", sut.id_SPORTO_SALE);
				args.Add("?savinink", 102);
			});

		return (int)nr;
	}

	public static void UpdateSportoSale(SportoSaleCE sutCE)
	{
		var query =
			$@"UPDATE `sporto_sales`
			SET
				`salis` = ?salis,
				`miestas` = ?miestas,
				`adresas` = ?adresas,
				`darbo_laikas` = ?darblaik,
				`vietu_kiekis` = ?vietkiek,
				`irengimo_data` = ?irengdat,
				`darbuotoju_kiekis` = ?darbkiek,
				`ar_dirba_visa_para` = ?ardirbvispar,
				`fk_SAVININKASSavininko_asmens_kodas` = ?savinink
			WHERE id_SPORTO_SALE=?id";

		Sql.Update(query, args => {
			//make a shortcut
			var sut = sutCE.SportoSale;

			//
			args.Add("?salis", sut.Salis);
				args.Add("?miestas", sut.Miestas);
				args.Add("?adresas", sut.Adresas);
				args.Add("?darblaik", sut.Darbo_laikas);
				args.Add("?vietkiek", sut.Vietu_kiekis);
				args.Add("?irengdat", sut.Irengimo_data);
				args.Add("?darbkiek", sut.Darbuotoju_kiekis);
				args.Add("?ardirbvispar", 1);
				args.Add("?savinink", 102);

			    args.Add("?id", sut.id_SPORTO_SALE);
		});
	}

	public static void DeleteSportoSale(int id)
	{
		var query = $@"DELETE FROM `sporto_sales` where id_SPORTO_SALE=?id";
		Sql.Delete(query, args => {
			args.Add("?id", id);
		});
	}

/*
	public static List<SutartiesBusena> ListSutartiesBusena()
	{
		var query = $@"SELECT * FROM `{Config.TblPrefix}sutarties_busenos` ORDER BY id ASC";
		var drc = Sql.Query(query);

		var result =
			Sql.MapAll<SutartiesBusena>(drc, (dre, t) => {
				t.Id = dre.From<int>("id");
				t.Name = dre.From<string>("name");
			});

		return result;
	}
    */

	public static List<SportoSaleCE.UzsakymasM> ListUzsakymas(int uzsakymasId)
	{
		var query =
			$@"SELECT *
			FROM `uzsakymai`
			WHERE id_UZSAKYMAS = ?uzsakymasID
			ORDER BY fk_SPORTO_SALEid_SPORTO_SALE ASC, fk_IRANGAid_IRANGA ASC, fk_GAMYKLAid_GAMYKLA ASC";

		var drc =
			Sql.Query(query, args => {
				args.Add("?uzsakymasID", uzsakymasId);
			});

		var result =
			Sql.MapAll<SportoSaleCE.UzsakymasM>(drc, (dre, t) => {
				t.Uzsakymas =
					//we use JSON here to make serialization/deserializaton of composite key more convenient
					JsonConvert.SerializeObject(new {
						FKUzsakymas = dre.From<int>("id_UZSAKYMAS"),
                        //FKSportoSale = dre.From<int>("fk_SPORTO_SALEid_SPORTO_SALE")
					});
				t.Kiekis = dre.From<int>("kiekis");
				t.Data = dre.From<DateTime>("data");
			});

		for( int i = 0; i < result.Count; i++ )
			result[i].InListId = i;

		return result;
	}

	public static void InsertUzsakymas(int uzsakymasId, SportoSaleCE.UzsakymasM up)
	{
		//deserialize 'Paslauga' foreign keys from 'UzsakytaPaslauga' view model key
		var fks =
			JsonConvert.DeserializeAnonymousType(
				up.Uzsakymas,
				//this creates object of correct shape that is filled in by the JSON deserializer
				new {
					FkUzsakymas = 1,
				}
			);

		//
		var query =
			$@"INSERT INTO `uzsakymai`
				(
					id_UZSAKYMAS,
					fk_SPORTO_SALEid_SPORTO_SALE,
					fk_IRANGAid_IRANGA,
                    fk_GAMYKLAid_GAMYKLA,
					kiekis,
					data
				)
				VALUES(
					?id_uzsakymas,
					?sporto_sale,
					?fk_iranga,
                    ?fk_gamykla,
					?kiekis,
					?data
				)";

		Sql.Insert(query, args => {
			args.Add("?id_uzsakymas", uzsakymasId);
			args.Add("?kaina", up.Kiekis);
			args.Add("?kiekis", up.Data);
		});
	}

	public static void DeleteUzsakymasForSportoSale(int uzsakymas)
	{
		var query =
			$@"DELETE FROM a
			USING `uzsakymai` as a
			WHERE a.id_UZSAKYMAS=?uzsakymasID";

		Sql.Delete(query, args => {
			args.Add("?uzsakymasID", uzsakymas);
		});
	}
}