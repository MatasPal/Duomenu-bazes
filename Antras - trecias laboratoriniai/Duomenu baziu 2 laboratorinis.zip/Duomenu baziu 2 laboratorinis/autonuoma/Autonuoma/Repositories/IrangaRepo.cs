namespace Org.Ktu.Isk.P175B602.Autonuoma.Repositories;

using MySql.Data.MySqlClient;

using Org.Ktu.Isk.P175B602.Autonuoma.Models;


/// <summary>
/// Database operations related to 'Iranga' entity.
/// </summary>
public class IrangaRepo
{
	public static List<Iranga> List()
	{
		var query = $@"SELECT * FROM `irangos` ORDER BY id_iranga ASC";
		var drc = Sql.Query(query);

		var result = 
			Sql.MapAll<Iranga>(drc, (dre, t) => {
				t.Tipas = dre.From<string>("tipas");
                t.Pagaminimo_data = dre.From<DateTime>("pagaminimo_data");
				t.Gamintojas = dre.From<string>("gamintojas");
				t.Garantijos_laikotarpis = dre.From<int>("garantijos_laikotarpis");
				t.Medziagos_is_kuriu_pagaminta = dre.From<string>("medziagos_is_kuriu_pagaminta");
				t.id_IRANGA = dre.From<int>("id_iranga");
			});

		return result;
	}

	public static Iranga Find(int idirang)
	{
		var query = $@"SELECT * FROM `irangos` WHERE id_iranga=?idirang";

		var drc =
			Sql.Query(query, args => {
				args.Add("?idirang", idirang);
			});

		if( drc.Count > 0 )
		{
			var result = 
				Sql.MapOne<Iranga>(drc, (dre, t) => {
					t.Tipas = dre.From<string>("tipas");
                    t.Pagaminimo_data = dre.From<DateTime>("pagaminimo_data");
				    t.Gamintojas = dre.From<string>("gamintojas");
				    t.Garantijos_laikotarpis = dre.From<int>("garantijos_laikotarpis");
				    t.Medziagos_is_kuriu_pagaminta = dre.From<string>("medziagos_is_kuriu_pagaminta");
				    t.id_IRANGA = dre.From<int>("id_iranga");
				});

			return result;
		}

		return null;
	}

	public static void Insert(Iranga iranga)
	{
		var query =
			$@"INSERT INTO `irangos`
			(
				tipas,
                pagaminimo_data,
                gamintojas,
                garantijos_laikotarpis,
                medziagos_is_kuriu_pagaminta,
                id_iranga
			)
			VALUES(
				?tipas,
				?pagamdata,
				?gamintoj,
				?garantlaik,
				?medzpagam,
				?idirang
			)";

		Sql.Insert(query, args => {
			args.Add("?tipas", iranga.Tipas);
			args.Add("?pagamdata", iranga.Pagaminimo_data);
			args.Add("?gamintoj", iranga.Gamintojas);
			args.Add("?garantlaik", iranga.Garantijos_laikotarpis);
			args.Add("?medzpagam", iranga.Medziagos_is_kuriu_pagaminta);
			args.Add("?idirang", iranga.id_IRANGA);
		});
	}

	public static void Update(Iranga iranga)
	{
		var query =
			$@"UPDATE `irangos`
			SET
				tipas=?tipas,
				pagaminimo_data=?pagamdata,
				gamintojas=?gamintoj,
				garantijos_laikotarpis=?garantlaik,
				medziagos_is_kuriu_pagaminta=?medzpagam
			WHERE
				id_IRANGA=?idirang";

		Sql.Update(query, args => {
			args.Add("?tipas", iranga.Tipas);
			args.Add("?pagamdata", iranga.Pagaminimo_data);
			args.Add("?gamintoj", iranga.Gamintojas);
			args.Add("?garantlaik", iranga.Garantijos_laikotarpis);
			args.Add("?medzpagam", iranga.Medziagos_is_kuriu_pagaminta);
			args.Add("?idirang", iranga.id_IRANGA);
		});
	}

	public static void Delete(int id)
	{
		var query = $@"DELETE FROM `irangos` WHERE id_iranga=?id";
		Sql.Delete(query, args => {
			args.Add("?id", id);
		});
	}
}
