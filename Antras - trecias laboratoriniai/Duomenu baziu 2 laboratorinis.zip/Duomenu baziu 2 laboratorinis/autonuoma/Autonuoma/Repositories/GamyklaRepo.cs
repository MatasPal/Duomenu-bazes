namespace Org.Ktu.Isk.P175B602.Autonuoma.Repositories;

using MySql.Data.MySqlClient;

using Org.Ktu.Isk.P175B602.Autonuoma.Models;


/// <summary>
/// Database operations related to 'Gamykla' entity.
/// </summary>
public class GamyklaRepo
{
	public static List<Gamykla> List()
	{
		var query = $@"SELECT * FROM `gamyklos` ORDER BY id_gamykla ASC";
		var drc = Sql.Query(query);

		var result = 
			Sql.MapAll<Gamykla>(drc, (dre, t) => {
				t.Salis = dre.From<string>("salis");
				t.Miestas = dre.From<string>("miestas");
				t.Adresas = dre.From<string>("adresas");
				t.Darbo_laikas = dre.From<DateTime>("darbo_laikas");
				t.Irangos_kiekis = dre.From<string>("irangos_kiekis");
				t.id_GAMYKLA = dre.From<int>("id_gamykla");
			});

		return result;
	}

	public static Gamykla Find(int idgamykl)
	{
		var query = $@"SELECT * FROM `gamyklos` WHERE id_gamykla=?idgamykl";

		var drc =
			Sql.Query(query, args => {
				args.Add("?idgamykl", idgamykl);
			});

		if( drc.Count > 0 )
		{
			var result = 
				Sql.MapOne<Gamykla>(drc, (dre, t) => {
					t.Salis = dre.From<string>("salis");
				    t.Miestas = dre.From<string>("miestas");
				    t.Adresas = dre.From<string>("adresas");
				    t.Darbo_laikas = dre.From<DateTime>("darbo_laikas");
				    t.Irangos_kiekis = dre.From<string>("irangos_kiekis");
				    t.id_GAMYKLA = dre.From<int>("id_gamykla");
				});

			return result;
		}

		return null;
	}

	public static void Insert(Gamykla gamykla)
	{
		var query =
			$@"INSERT INTO `gamyklos`
			(
				salis,
                miestas,
                adresas,
                darbo_laikas,
                irangos_kiekis,
                id_gamykla
			)
			VALUES(
				?salis,
				?miestas,
				?adresas,
				?darblaik,
				?irangkiek,
				?idgamykl
			)";

		Sql.Insert(query, args => {
			args.Add("?salis", gamykla.Salis);
			args.Add("?miestas", gamykla.Miestas);
			args.Add("?adresas", gamykla.Adresas);
			args.Add("?darblaik", gamykla.Darbo_laikas);
			args.Add("?irangkiek", gamykla.Irangos_kiekis);
			args.Add("?idgamykl", gamykla.id_GAMYKLA);
		});
	}

	public static void Update(Gamykla gamykla)
	{
		var query =
			$@"UPDATE `gamyklos`
			SET
				salis=?salis,
				miestas=?miestas,
				adresas=?adresas,
				darbo_laikas=?darblaik,
				irangos_kiekis=?irangkiek
			WHERE
				id_GAMYKLA=?idgamykl";

		Sql.Update(query, args => {
			args.Add("?salis", gamykla.Salis);
			args.Add("?miestas", gamykla.Miestas);
			args.Add("?adresas", gamykla.Adresas);
			args.Add("?darblaik", gamykla.Darbo_laikas);
			args.Add("?irangkiek", gamykla.Irangos_kiekis);
			args.Add("?idgamykl", gamykla.id_GAMYKLA);
		});
	}

	public static void Delete(int id)
	{
		var query = $@"DELETE FROM `gamyklos` WHERE id_gamykla=?id";
		Sql.Delete(query, args => {
			args.Add("?id", id);
		});
	}
}
