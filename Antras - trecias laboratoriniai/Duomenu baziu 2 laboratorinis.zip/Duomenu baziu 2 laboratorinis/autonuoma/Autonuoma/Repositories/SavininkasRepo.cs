namespace Org.Ktu.Isk.P175B602.Autonuoma.Repositories;

using MySql.Data.MySqlClient;

using Org.Ktu.Isk.P175B602.Autonuoma.Models;


/// <summary>
/// Database operations related to 'Savininkas' entity.
/// </summary>
public class SavininkasRepo
{
	public static List<Savininkas> List()
	{
		var query = $@"SELECT * FROM `savininkai` ORDER BY savininko_asmens_kodas ASC";
		var drc = Sql.Query(query);

		var result = 
			Sql.MapAll<Savininkas>(drc, (dre, t) => {
				
				t.Vardas = dre.From<string>("vardas");
				t.Pavarde = dre.From<string>("pavarde");
                t.Savininko_asmens_kodas = dre.From<int>("savininko_asmens_kodas");
				t.Amzius = dre.From<int>("amzius");
				t.Banko_saskaita = dre.From<string>("banko_saskaita");
				t.Adresas = dre.From<string>("adresas");
				t.Lytis = dre.From<int>("lytis");
			});

		return result;
	}

	public static Savininkas Find(int asmkodas)
	{
		var query = $@"SELECT * FROM `savininkas` WHERE savininko_asmens_kodas=?asmkodas";

		var drc =
			Sql.Query(query, args => {
				args.Add("?asmkodas", asmkodas);
			});

		if( drc.Count > 0 )
		{
			var result = 
				Sql.MapOne<Savininkas>(drc, (dre, t) => {
					t.Vardas = dre.From<string>("vardas");
				    t.Pavarde = dre.From<string>("pavarde");
                    t.Savininko_asmens_kodas = dre.From<int>("savininko_asmens_kodas");
				    t.Amzius = dre.From<int>("amzius");
				    t.Banko_saskaita = dre.From<string>("banko_saskaita");
				    t.Adresas = dre.From<string>("adresas");
                    t.Lytis = dre.From<int>("lytis");
				});

			return result;
		}

		return null;
	}

	public static void Insert(Savininkas savininkas)
	{
		var query =
			$@"INSERT INTO `savininkas`
			(
				vardas,
				pavarde,
                asmens_kodas,
                amzius,
                banko_saskaita,
				adresas,
				lytis
			)
			VALUES(
				?vardas,
				?pavarde,
                ?asmkod,
				?amz,
				?bank_sask,
				?adres,
				?lyt
			)";

		Sql.Insert(query, args => {
			args.Add("?vardas", savininkas.Vardas);
			args.Add("?pavarde", savininkas.Pavarde);
            args.Add("?asmkod", savininkas.Savininko_asmens_kodas);
			args.Add("?amz", savininkas.Amzius);
			args.Add("?bank_sask", savininkas.Banko_saskaita);
			args.Add("?adres", savininkas.Adresas);
			args.Add("?lyt", savininkas.Lytis);
		});
	}

	public static void Update(Savininkas savininkas)
	{
		var query =
			$@"UPDATE `savininkai`
			SET
				vardas=?vardas,
				pavarde=?pavarde,
				amzius=?amz,
				banko_saskaita=?bank_sask,
				adresas=?adres
				lytis=?lyt
			WHERE
				savininko_asmens_kodas=?asmkod";

		Sql.Update(query, args => {
			args.Add("?vardas", savininkas.Vardas);
			args.Add("?pavarde", savininkas.Pavarde);
            args.Add("?asmkod", savininkas.Savininko_asmens_kodas);
			args.Add("?amz", savininkas.Amzius);
			args.Add("?bank_sask", savininkas.Banko_saskaita);
			args.Add("?adres", savininkas.Adresas);
			args.Add("?lyt", savininkas.Lytis);
		});
	}

	public static void Delete(int id)
	{
		var query = $@"DELETE FROM `savininkai` WHERE savininko_asmens_kodas=?id";
		Sql.Delete(query, args => {
			args.Add("?id", id);
		});
	}
}
